Sprint 3 -> Cadastro de entidade

Cadastro de jogos na biblioteca do usuário

info: Para cadastrar um jogo o usuário deve inserir um nome e plataforma válidas. Você pode checar quais jogos e plataformas são permitidos acessando o arquivo 'banco_jogos.json' na pasta data.

obs: Não rode o site abrindo seu arquivo HTML diretamente, é necessário abrir um servidor usando o Live-server do VS Code ou utilizar o link do Replit.

link: https://Biblioteca.tuliobrant.repl.co 
